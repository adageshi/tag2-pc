@echo off
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-ManualLauncher.ps1" >nul
if errorlevel 1 (
 pause
 exit /b 1
)
echo Launcher updated. Open Tag2Launcher.exe.

#requires -Version 5.1
[CmdletBinding()]
param(
    [string]$InstallRoot,
    [string]$PackageRoot,
    [ValidateSet('none','staged','after-first-replacement','after-config-replacement')][string]$TestFailAt = 'none'
)
$ErrorActionPreference = 'Stop'
# PS5.1 initializes parameter defaults before PSScriptRoot is available.
if (-not $InstallRoot) { $InstallRoot = $PSScriptRoot }
if (-not $PackageRoot) { $PackageRoot = Join-Path $PSScriptRoot 'launcher-update' }
$requiredMigration = @{
    'updates/Trust-Tag2.ps1' = '3553db6b157a2788d46dc2420542c14b2454cfe14b41e037b10cdc1063c48f19'
    'updates/Update-Common.ps1' = 'd02326ee5e9b52dd7d75d195db2f8e6f7f8321086cb4abb53adc4a141aa0f135'
    'updates/Update-Tag2.ps1' = 'a74c0c91844a9cb91efa7c18328772c97777aac48a870a9493d53028d3b62813'
}
# The manual entry point and these public pins are distributed together. No key is
# fetched from a feed. Check source bytes before dot-sourcing executable scripts.
$PackageRoot = [IO.Path]::GetFullPath($PackageRoot)
foreach ($name in @('updates/Trust-Tag2.ps1','updates/Update-Common.ps1')) {
    $path = Join-Path $PackageRoot $name.Replace('/', '\')
    if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -cne $requiredMigration[$name]) { throw 'The manual launcher trust files are incomplete or changed.' }
}
. (Join-Path $PackageRoot 'updates/Update-Common.ps1')
. (Join-Path $PackageRoot 'updates/Trust-Tag2.ps1')
if ($TestFailAt -ne 'none' -and -not $script:Tag2AllowTestInterruptions) { throw 'Bootstrap test failures are disabled.' }
$root = (Assert-LocalPath $InstallRoot).TrimEnd('\')
$PackageRoot = Assert-LocalPath $PackageRoot
if ($root.Length -lt 4) { throw 'Choose the folder containing Tag2Launcher.exe, not a drive root.' }
$drive = New-Object IO.DriveInfo([IO.Path]::GetPathRoot($root))
if ($drive.DriveType -ne [IO.DriveType]::Fixed -or $drive.DriveFormat -ne 'NTFS') { throw 'Atomic installations require a local fixed NTFS volume.' }
[void][IO.Directory]::CreateDirectory($root)
$lock=$null; $stage=$null; $keepStage=$false
$held=New-Object 'Collections.Generic.List[IO.FileStream]'
$files=New-Object 'Collections.Generic.List[object]'
$changed=New-Object 'Collections.Generic.List[object]'
try {
    $lock=New-Object IO.FileStream((Assert-LocalPath (Join-Path $root '.update.lock')),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    $manifestPath=Assert-LocalPath (Join-Path $PackageRoot 'bootstrap.json')
    $signaturePath=Assert-LocalPath (Join-Path $PackageRoot 'bootstrap.sig')
    if((Get-Item -LiteralPath $manifestPath).Length -gt 65536 -or (Get-Item -LiteralPath $signaturePath).Length -gt 1024){throw 'Bootstrap metadata exceeds its size bound.'}
    $bytes=[IO.File]::ReadAllBytes($manifestPath);$signature=[IO.File]::ReadAllBytes($signaturePath)
    $rsa=[Security.Cryptography.RSA]::Create()
    try {
        $rsa.FromXmlString($script:Tag2PublicKeyXml)
        if($rsa.KeySize -ne 4096 -or -not $rsa.VerifyData($bytes,$signature,[Security.Cryptography.HashAlgorithmName]::SHA256,[Security.Cryptography.RSASignaturePadding]::Pkcs1)){throw 'Manual launcher signature verification failed.'}
    }finally{$rsa.Dispose()}
    $m=$script:Utf8.GetString($bytes)|ConvertFrom-Json
    foreach($name in @('schema','kind','product','platform','channel','build','version','update_manifest_uri','files')){if($null -eq $m.PSObject.Properties[$name]){throw 'Incomplete bootstrap receipt.'}}
    if($m.schema -ne 1 -or $m.kind -cne 'tag2-launcher-bootstrap' -or $m.product -cne $script:Tag2Product -or $m.platform -cne $script:Tag2Platform -or $m.channel -cne $script:Tag2Channel){throw 'Manual launcher product contract mismatch.'}
    if(($m.build -isnot [int] -and $m.build -isnot [long]) -or $m.build -lt $script:Tag2MinimumBuild -or $m.version -isnot [string] -or $m.version -cnotmatch '^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$'){throw 'Invalid bootstrap release version.'}
    if($m.update_manifest_uri -cne $script:Tag2ManifestUri){throw 'Manual launcher feed does not match its pinned trust line.'}
    # This reads downgrade protection; the manual launcher never selects or edits
    # state/current/previous/pending, native current.json, versions or user files.
    $statePath=Assert-LocalPath (Join-Path $root 'state.json')
    if([IO.File]::Exists($statePath)){
        if((Get-Item -LiteralPath $statePath).Length -gt 65536){throw 'Invalid installation state size.'}
        $state=[IO.File]::ReadAllText($statePath,$script:Utf8)|ConvertFrom-Json
        foreach($name in @('schema','current','previous','highest_build','highest_version','highest_manifest_sha256','pending')){if($null -eq $state.PSObject.Properties[$name]){throw 'Installation state is damaged; manual downgrade protection was not reset.'}}
        if($state.schema -ne 1 -or ($state.highest_build -isnot [int] -and $state.highest_build -isnot [long]) -or $state.highest_build -lt 0 -or ($state.highest_build -gt 0 -and $state.highest_manifest_sha256 -cnotmatch '^[a-f0-9]{64}$')){throw 'Invalid installation state.'}
        if($m.build -lt $state.highest_build -or [version]$m.version -lt [version]$state.highest_version){throw 'Manual launcher downgrade refused.'}
    }
    $allowed=@('README.txt','RELEASE-NOTES.txt','Repair-Launcher.ps1','Tag2.Launcher.Core.dll','Tag2Launcher.exe','Tag2Launcher.exe.config','bin/msvcp140.dll','bin/msvcp140_atomic_wait.dll','bin/Tag2Controllers.exe','bin/Tag2ShaderCache.exe','bin/Tag2Update.exe','bin/vcruntime140.dll','bin/vcruntime140_1.dll','licenses/Oxanium-OFL.txt','licenses/UI-ASSETS.txt','licenses/xxHash-Cache.txt','updates/Update-Common.ps1','updates/Update-Tag2.ps1','updates/Trust-Tag2.ps1')
    $seen=New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal)
    if(@($m.files).Count -ne $allowed.Count){throw 'Manual launcher component list is incomplete.'}
    foreach($entry in $m.files){
        if($null -eq $entry.PSObject.Properties['path'] -or $null -eq $entry.PSObject.Properties['size'] -or $null -eq $entry.PSObject.Properties['sha256']){throw 'Incomplete manual component.'}
        if($entry.path -isnot [string] -or $entry.path -cnotin $allowed -or -not $seen.Add($entry.path) -or ($entry.size -isnot [int] -and $entry.size -isnot [long]) -or $entry.size -lt 1 -or $entry.size -gt 4MB -or $entry.sha256 -cnotmatch '^[a-f0-9]{64}$'){throw 'Invalid manual launcher component.'}
        $source=Assert-LocalPath (Join-Path $PackageRoot $entry.path.Replace('/','\'))
        if((Get-Item -LiteralPath $source).Length -ne $entry.size -or (Get-FileHash -LiteralPath $source).Hash.ToLowerInvariant() -cne $entry.sha256){throw 'Manual launcher component integrity check failed.'}
        if($requiredMigration.ContainsKey($entry.path) -and $entry.sha256 -cne $requiredMigration[$entry.path]){throw 'The manual payload would change the pinned update trust.'}
        $target=Assert-LocalPath (Join-Path $root $entry.path.Replace('/','\'))
        $files.Add([pscustomobject]@{name=$entry.path;source=$source;target=$target;hash=$entry.sha256;temp=$null;backup=$null;existed=[IO.File]::Exists($target)})
    }
    # Canonical order is independent of receipt array order. Common/Updater must
    # precede Trust so Get-Release remains usable across an interrupted rotation.
    $orderedFiles=New-Object 'Collections.Generic.List[object]'
    foreach($file in ($files|Sort-Object {[array]::IndexOf($allowed,$_.name)})){$orderedFiles.Add($file)}
    $files=$orderedFiles
    $configPath=Assert-LocalPath (Join-Path $root 'launcher.json')
    $config=if([IO.File]::Exists($configPath)){
        if((Get-Item -LiteralPath $configPath).Length -gt 1048576){throw 'Invalid launcher configuration size.'}
        $value=[IO.File]::ReadAllText($configPath,$script:Utf8)|ConvertFrom-Json
        if($value -isnot [pscustomobject]){throw 'Invalid launcher configuration.'};$value
    }else{[pscustomobject]@{Build=16;Protocol=3;ApiBase='https://api.frameperfectlab.com/tag2/v1/';UpdateManifestUri='';ProfileTtlMs=120000}}
    $needsConfig=$null -eq $config.PSObject.Properties['UpdateManifestUri'] -or $config.UpdateManifestUri -cne $script:Tag2ManifestUri
    if($needsConfig){$config|Add-Member -MemberType NoteProperty -Name UpdateManifestUri -Value $script:Tag2ManifestUri -Force}
    # Preflight all existing destinations before any launcher/config replacement.
    # Do not kill the launcher or scan processes; a locked file asks the user to close it.
    foreach($path in @($files|ForEach-Object {$_.target})+@($configPath)){
        if([IO.File]::Exists($path)){$held.Add([IO.File]::Open($path,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None))}
    }
    $stage=Assert-LocalPath (Join-Path $root ('.launcher-bootstrap-'+[guid]::NewGuid().ToString('N')))
    [void][IO.Directory]::CreateDirectory($stage)
    foreach($file in $files){
        $file.temp=Join-Path $stage ('new-'+$files.IndexOf($file));$file.backup=Join-Path $stage ('old-'+$files.IndexOf($file))
        [IO.File]::Copy($file.source,$file.temp,$false)
        if((Get-FileHash -LiteralPath $file.temp).Hash.ToLowerInvariant() -cne $file.hash){throw 'Staged manual launcher component changed.'}
    }
    if($needsConfig){
        $temp=Join-Path $stage 'new-config';Write-DurableBytes $temp $script:Utf8.GetBytes(($config|ConvertTo-Json -Depth 32 -Compress))
        $files.Add([pscustomobject]@{name='launcher.json';source=$null;target=$configPath;hash=(Get-FileHash -LiteralPath $temp).Hash.ToLowerInvariant();temp=$temp;backup=(Join-Path $stage 'old-config');existed=[IO.File]::Exists($configPath)})
    }
    if($TestFailAt -eq 'staged'){throw 'Injected bootstrap staging failure.'}
    foreach($handle in $held){$handle.Dispose()};$held.Clear()
    foreach($file in $files){
        if($file.existed -and (Get-FileHash -LiteralPath $file.target).Hash.ToLowerInvariant() -ceq $file.hash){Unblock-File -LiteralPath $file.target;continue}
        if($file.existed){[IO.File]::Replace($file.temp,$file.target,$file.backup)}else{[void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($file.target));[IO.File]::Move($file.temp,$file.target)}
        $changed.Add($file)
        if((Get-FileHash -LiteralPath $file.target).Hash.ToLowerInvariant() -cne $file.hash){throw 'Installed manual launcher integrity check failed.'}
        Unblock-File -LiteralPath $file.target
        if($TestFailAt -eq 'after-first-replacement'){throw 'Injected bootstrap replacement failure.'}
        if($TestFailAt -eq 'after-config-replacement' -and $file.name -ceq 'launcher.json'){throw 'Injected bootstrap configuration replacement failure.'}
    }
    [ordered]@{manual_launcher_installed=$true;build=$m.build;files_changed=$changed.Count;update_manifest_uri=$script:Tag2ManifestUri;installation_state_changed=$false;user_data_changed=$false}|ConvertTo-Json -Compress
}catch{
    $failure=$_.Exception.Message
    foreach($handle in $held){$handle.Dispose()};$held.Clear()
    for($i=$changed.Count-1;$i -ge 0;$i--){
        $file=$changed[$i]
        try{if($file.existed){[IO.File]::Replace($file.backup,$file.target,[NullString]::Value)}elseif([IO.File]::Exists($file.target)){[IO.File]::Delete($file.target)}}catch{$keepStage=$true;$failure+=' A launcher backup could not be restored; keep '+$stage}
    }
    [Console]::Error.WriteLine('Tag2 manual launcher: '+$failure+' Close the launcher and retry the same manual package.')
    exit 1
}finally{
    foreach($handle in $held){$handle.Dispose()}
    if($lock){$lock.Dispose()}
    if($stage -and -not $keepStage -and [IO.Directory]::Exists($stage)){Remove-WorkDirectory $stage $root}
}

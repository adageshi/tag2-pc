TAG2 PC 0.16.21

Close TAG2 and its launcher. Extract the ENTIRE launcher ZIP into the SAME folder
as the existing Tag2Launcher.exe, keeping the launcher-update subfolder.
Run Install-Launcher.cmd, then open Tag2Launcher.exe and choose Install update.
For a fresh installation, extract to an empty folder on a local fixed NTFS drive
and run the same installer. Internet access is needed for initial setup.

Keep the whole installation folder together to retain your account, settings and
saves. Compatible built games are patched automatically. The game ISO and matching
Xbox 360 Title Update are required for a first build and are not included.

Full setup guide: https://github.com/adageshi/tag2-pc/blob/main/SETUP.md
Development sources and internal input work are private.

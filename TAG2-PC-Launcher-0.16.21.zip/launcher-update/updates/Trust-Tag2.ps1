# Bootstrap trust is distributed with the client, never downloaded from the feed.
# TAG2 preview release key primary public key rotated manually on 2026-10-23; old public key is local-only.
$script:Tag2PublicKeyXml = '<RSAKeyValue><Modulus>8E0cyLZqfOvSBB0iHjXtIpLgiim0avuJRDyfXnohQVprQ4505PJRQkGLcKmPUSG6maoLZs7JDFJPEofxT2/Q/6yi+C1ittViHj69RnUZFR2HOt/d1m8Sxq2jGxWkg61lezlUJpba1UWOa96sE4rSaj0RMqPukUzOAS7cNCUj19NrTqXV4NdU6rT5QEdMnf82iKUBxvfKTv9KTvDQoNHskOnf+VZK27nEitRdNlg/67LodcIg7WXW+VGVaQdh8uBQ5oCdCsp6avUnLnRTW1qkzdClB+5EVR3L1/9rb+zc4SoaOfeorB5HDqZXs1GBO+DZFs7CWjO8a1cF2MpQlaOQyCdQTznp7xrKk8wGz/hc2eoGkWXVEoCC2ueqwZVD5CFNJn7panvYS3wrUh+rsa8h74Id1/nupOnT926K3SULADG8wLDcdV6XUEtv+sWVQ35ovLNh3Ma6bwAdFVT7BX/XyPg/DV11KkavJfsNZYMrSEjWbMxwhrwOvvXpcQdReSWYJLFSz7v6CBDXC2tOI1iPno0uBY18IH+F+AuFeKB64s4EYYCQ8fOqKYaIeoMg77OaUBfiCYq1hrZd4surVCRV0bw86epqPmsIuby8dxntA/ntc58pVSKTkwBG6eQOKGpekL3Uv8xRile5gBbJoWzWGKGQSPNE68ie+UDD0X5MkrU=</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>'
$script:Tag2Product = 'tag2-pc'
$script:Tag2Platform = 'windows-x64'
$script:Tag2Channel = 'preview'
$script:Tag2MinimumBuild = [long]37
$script:Tag2LegacyPublicKeyXml = '<RSAKeyValue><Modulus>0ZEyNGCVpgutkjXkfY7l7i2oUwHyiEv3NDqHCwo+IyqVgXB8s7Xt1QTVQCMz73MteXokPc3W+s25CodPYwNj2423PF3tUQAD3ZUaeGpyg5vN7ZaEAAO84ak5rc81gngduR4cmxQ5DVvbhOqfhVizz9O8LbyPAykvdibhJjn+qW8MT0V/8thIrUhxrq1X+77iIkFVUaBlLu7Ch1vmGIIgObSdyBTQIUJZCWeZccPi/Cmw45dXJe4H30Gb1t0FU1DOAWebuiCTstOmVwCFb+7PNvLTVCYjosQD0+kUbK3Jj3pX7zr36VJDaBnaDS8t5JkYXIRcpddmNudRwO1pFqIvYkZwKNGeVl2v/a4PWtu8pQBdlhbaEEP0pQNGOwkp5UD4aqEHHrvS4WoPYlwCSPBlPE7lU7d1zPgdJgttIiKfcepxYkKY6kckac7QhtCXB0H6VGtVqG2CsaelJeXGKJAbX1xySObkMapCj4MZNoWvpLaWrGScq6HZJJnbCS9DMyIp</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>'
$script:Tag2LegacyMinimumBuild = [long]16
$script:Tag2LegacyMaximumBuild = [long]36
$script:Tag2ManifestUri = 'https://api.frameperfectlab.com/tag2/releases/tag2-preview-v2.json'
$script:Tag2AllowTestTransport = $false
$script:Tag2AllowTestInterruptions = $false

#requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$InstallRoot,
    [ValidateSet('Apply', 'Check', 'Recover', 'Rollback', 'Status', 'Resolve')][string]$Action = 'Status',
    [string]$ManifestUri,
    [switch]$RequireLocalBuildTools,
    [ValidateSet('none', 'during-download', 'download', 'extract', 'version', 'activate', 'activation-failure')][string]$TestInterruptAt = 'none'
)
[Threading.Thread]::CurrentThread.CurrentUICulture = [Globalization.CultureInfo]::GetCultureInfo('en-US')
[Threading.Thread]::CurrentThread.CurrentCulture = [Globalization.CultureInfo]::InvariantCulture
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Update-Common.ps1')
. (Join-Path $PSScriptRoot 'Trust-Tag2.ps1')
$lock = $null; $stage = $null
$script:ActivatedNewRelease = $false

function New-EmptyState {
    return [pscustomobject]@{ schema = 1; current = $null; previous = $null; highest_build = [long]0; highest_version = '0.0.0'; highest_manifest_sha256 = $null; pending = $null }
}

function Read-State {
    if (-not [IO.File]::Exists($script:StatePath)) { return New-EmptyState }
    if ((Get-Item -LiteralPath $script:StatePath).Length -gt 65536) { throw 'Invalid installation state size.' }
    $state = [IO.File]::ReadAllText($script:StatePath, $script:Utf8) | ConvertFrom-Json
    foreach ($field in @('schema', 'current', 'previous', 'highest_build', 'highest_version', 'highest_manifest_sha256', 'pending')) {
        if ($null -eq $state.PSObject.Properties[$field]) { throw 'Installation state is damaged; refusing an unsafe reset of downgrade protection.' }
    }
    if ($state.schema -ne 1 -or ($state.highest_build -isnot [int] -and $state.highest_build -isnot [long]) -or $state.highest_build -lt 0) { throw 'Invalid installation state.' }
    $null = [version]$state.highest_version
    if ($state.highest_build -gt 0 -and $state.highest_manifest_sha256 -cnotmatch '^[a-f0-9]{64}$') { throw 'Invalid highest manifest hash.' }
    foreach ($id in @($state.current, $state.previous)) { if ($id -and $id -cnotmatch '^b[1-9][0-9]*-[a-f0-9]{64}$') { throw 'Invalid installed release identifier.' } }
    return $state
}

function Get-Release([string]$Id, [bool]$VerifyArchive = $false) {
    if ($Id -cnotmatch '^b[1-9][0-9]*-[a-f0-9]{64}$') { throw 'Invalid installed release identifier.' }
    $directory = Assert-LocalPath (Join-Path $script:VersionsPath $Id)
    foreach ($name in @('manifest.json', 'manifest.sig', 'payload.zip', 'app')) { $null = Assert-LocalPath (Join-Path $directory $name) }
    $bytes = [IO.File]::ReadAllBytes((Join-Path $directory 'manifest.json'))
    $signature = [IO.File]::ReadAllBytes((Join-Path $directory 'manifest.sig'))
    $manifest = Read-InstalledManifest $bytes $signature
    if ($Id -cne ('b' + $manifest.build + '-' + $manifest.sha256)) { throw 'Installed release directory does not match its signature.' }
    if ($VerifyArchive) { Assert-Payload (Join-Path $directory 'payload.zip') $manifest }
    $entrypoint = Assert-LocalPath (Join-Path (Join-Path $directory 'app') $manifest.entrypoint.Replace('/', '\'))
    if (-not [IO.File]::Exists($entrypoint) -or (Get-Item -LiteralPath $entrypoint).Length -eq 0) { throw 'Installed release entrypoint is missing.' }
    return [pscustomobject]@{ directory = $directory; manifest = $manifest; entrypoint = $entrypoint }
}

function Recover-Pending($State) {
    if ($null -ne $State.pending) {
        foreach ($field in @('current', 'previous')) {
            if ($null -eq $State.pending.PSObject.Properties[$field]) { throw 'Invalid pending activation record.' }
            if ($State.pending.$field) { $null = Get-Release $State.pending.$field $true }
        }
        $State.current = $State.pending.current
        $State.previous = $State.pending.previous
        $State.pending = $null
        Write-AtomicJson $script:StatePath $State
        Write-Host 'Recovered interrupted activation; restored the previous selection and retained downgrade protection.'
    }
    return $State
}

function Test-Checkpoint([string]$Name) {
    if ($TestInterruptAt -eq $Name) { [Environment]::Exit(73) }
}

function Write-Status($State) {
    $result = [ordered]@{ installed = [bool]$State.current; highest_build = $State.highest_build; user_data_directory = (Join-Path $script:Root 'user-data') }
    if ($Action -eq 'Apply') { $result.update_changed = [bool]$script:ActivatedNewRelease }
    if ($State.current) {
        $release = Get-Release $State.current
        $result.app_directory = Join-Path $release.directory 'app'
        $result.entrypoint = $release.entrypoint
        foreach ($field in @('product', 'version', 'build', 'platform', 'channel', 'network_protocol', 'sha256')) { $result[$field] = $release.manifest.$field }
        $result.previous = $State.previous
        if ($Action -eq 'Resolve' -and $State.previous) {
            try {
                $previousRelease = Get-Release $State.previous $true
                $result.previous_app_directory = Join-Path $previousRelease.directory 'app'
                $result.previous_entrypoint = $previousRelease.entrypoint
                $result.previous_network_protocol = $previousRelease.manifest.network_protocol
                $result.previous_build = $previousRelease.manifest.build
            } catch { $result.previous_game_unavailable = $true }
        }
    }
    $result | ConvertTo-Json -Depth 5 -Compress
}

function Write-ProgressEvent([string]$Stage, [int]$Percent) {
    [Console]::Out.WriteLine((@{ event = 'progress'; stage = $Stage; percent = $Percent } | ConvertTo-Json -Compress))
}

try {
    if ($script:Tag2PublicKeyXml -eq 'UNCONFIGURED_TAG2_PUBLIC_KEY') { throw 'No Tag2 public key is pinned. Install a reviewed bootstrap trust file before using updates.' }
    if ($TestInterruptAt -ne 'none' -and -not $script:Tag2AllowTestInterruptions) { throw 'Interruption injection is disabled in this client.' }
    $script:Root = (Assert-LocalPath $InstallRoot).TrimEnd('\')
    if ($script:Root.Length -lt 4) { throw 'The installation root cannot be a drive root.' }
    $drive = New-Object IO.DriveInfo([IO.Path]::GetPathRoot($script:Root))
    if ($drive.DriveType -ne [IO.DriveType]::Fixed -or $drive.DriveFormat -ne 'NTFS') { throw 'Atomic installations require a local fixed NTFS volume.' }
    $null = [IO.Directory]::CreateDirectory($script:Root)
    $lockPath = Assert-LocalPath (Join-Path $script:Root '.update.lock')
    $lock = New-Object IO.FileStream($lockPath, [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
    $script:VersionsPath = Assert-LocalPath (Join-Path $script:Root 'versions')
    $script:StatePath = Assert-LocalPath (Join-Path $script:Root 'state.json')
    $stagingPath = Assert-LocalPath (Join-Path $script:Root '.staging')
    foreach ($path in @($script:VersionsPath, $stagingPath, (Assert-LocalPath (Join-Path $script:Root 'user-data')))) { $null = [IO.Directory]::CreateDirectory($path) }
    $state = Recover-Pending (Read-State)
    foreach ($old in Get-ChildItem -LiteralPath $stagingPath -Force) {
        if (-not $old.PSIsContainer -or $old.Name -cnotmatch '^[a-f0-9]{32}$') { throw 'Unexpected staging entry; refusing cleanup.' }
        Remove-WorkDirectory $old.FullName $stagingPath
    }
    # A crash while writing a new pointer can leave only this uncommitted temp file.
    foreach ($temp in Get-ChildItem -LiteralPath $script:Root -Filter 'state.json.*.tmp' -Force) {
        if ($temp.Name -cmatch '^state\.json\.[a-f0-9]{32}\.tmp$') { $null = Assert-LocalPath $temp.FullName; [IO.File]::Delete($temp.FullName) }
    }
    if ($Action -in @('Status', 'Resolve', 'Recover')) { Write-Status $state; exit 0 }
    if ($Action -eq 'Rollback') {
        if (-not $state.previous) { throw 'There is no previous release to restore.' }
        $null = Get-Release $state.previous $true
        $oldCurrent = $state.current
        $state.current = $state.previous
        $state.previous = $oldCurrent
        Write-AtomicJson $script:StatePath $state
        Write-Status $state
        exit 0
    }
    if (-not $ManifestUri) { throw 'Apply or Check requires -ManifestUri.' }
    Write-ProgressEvent 'manifest' 5
    $stage = Join-Path $stagingPath ([Guid]::NewGuid().ToString('N'))
    $null = [IO.Directory]::CreateDirectory($stage)
    $manifestPath = Join-Path $stage 'manifest.json'
    $signaturePath = Join-Path $stage 'manifest.sig'
    $uri = [uri]$ManifestUri
    if ($uri.Query) { throw 'Manifest URI must not contain a query string; use an immutable manifest URL.' }
    $null = Get-VerifiedTransportFile $uri $manifestPath 65536 $script:Tag2AllowTestTransport
    $null = Get-VerifiedTransportFile ([uri]($uri.AbsoluteUri + '.sig')) $signaturePath 1024 $script:Tag2AllowTestTransport
    $bytes = [IO.File]::ReadAllBytes($manifestPath)
    $manifest = Read-SignedManifest $bytes ([IO.File]::ReadAllBytes($signaturePath)) $script:Tag2PublicKeyXml
    if ($RequireLocalBuildTools -and ($null -eq $manifest.PSObject.Properties['local_build_tools'] -or $manifest.local_build_tools -isnot [bool] -or -not $manifest.local_build_tools)) { throw 'This signed release does not include matching local build tools. Keep this launcher and wait for the compatible update.' }
    $manifestHash = Get-BytesHash $bytes
    if ($manifest.build -lt $state.highest_build -or [version]$manifest.version -lt [version]$state.highest_version) { throw 'Downgrade refused.' }
    if ($manifest.build -eq $state.highest_build -and $manifestHash -cne $state.highest_manifest_sha256) { throw 'Reusing a previously accepted build number with different release metadata is forbidden.' }
    $id = 'b' + $manifest.build + '-' + $manifest.sha256
    if ($Action -eq 'Check') {
        [ordered]@{ event = 'check'; available = ($state.current -cne $id); version = $manifest.version; build = $manifest.build; network_protocol = $manifest.network_protocol; size = $manifest.size } | ConvertTo-Json -Compress
        exit 0
    }
    if ($state.current -ceq $id) { Write-Host 'This release is already active.'; Write-Status $state; exit 0 }
    $archivePath = Join-Path $stage 'payload.zip'
    $script:InterruptPayloadDownload = $TestInterruptAt -eq 'during-download'
    $script:ReportPayloadProgress = $true
    $null = Get-VerifiedTransportFile ([uri]$manifest.url) $archivePath $manifest.size $script:Tag2AllowTestTransport
    $script:InterruptPayloadDownload = $false
    $script:ReportPayloadProgress = $false
    Assert-Payload $archivePath $manifest
    Test-Checkpoint 'download'
    Write-ProgressEvent 'extract' 65
    $app = Join-Path $stage 'app'
    $null = [IO.Directory]::CreateDirectory($app)
    Expand-SafePayload $archivePath $app $manifest
    if ($RequireLocalBuildTools) {
        foreach ($name in @('builder/package.json','builder/build_native.py','builder/python/python.exe')) {
            $tool = Assert-LocalPath (Join-Path $app $name.Replace('/','\'))
            if (-not [IO.File]::Exists($tool) -or (Get-Item -LiteralPath $tool).Length -eq 0) { throw 'The signed release is missing its local build tools; the active version was not changed.' }
        }
    }
    Test-Checkpoint 'extract'
    $versionPath = Join-Path $script:VersionsPath $id
    if ([IO.Directory]::Exists($versionPath)) {
        $existing = Get-Release $id $true
        if ((Get-BytesHash ([IO.File]::ReadAllBytes((Join-Path $existing.directory 'manifest.json')))) -cne $manifestHash) { throw 'An immutable version directory already exists with different metadata.' }
        Remove-WorkDirectory $stage $stagingPath
    } else { [IO.Directory]::Move($stage, $versionPath) }
    $stage = $null
    Test-Checkpoint 'version'
    Write-ProgressEvent 'activate' 90
    $fallback = [pscustomobject]@{ current = $state.current; previous = $state.previous }
    $state.previous = $state.current
    $state.current = $id
    $state.highest_build = [long]$manifest.build
    $state.highest_version = $manifest.version
    $state.highest_manifest_sha256 = $manifestHash
    $state.pending = $fallback
    Write-AtomicJson $script:StatePath $state
    Test-Checkpoint 'activate'
    if ($TestInterruptAt -eq 'activation-failure') { throw 'Injected activation validation failure.' }
    $null = Get-Release $id $true
    $state.pending = $null
    Write-AtomicJson $script:StatePath $state
    $script:ActivatedNewRelease = $true
    Write-Host 'Update installed and activated.'
    Write-ProgressEvent 'complete' 100
    Write-Status $state
    exit 0
} catch {
    $failure = $_.Exception.Message
    if ($lock -and (Get-Variable StatePath -Scope Script -ErrorAction SilentlyContinue)) {
        try { $null = Recover-Pending (Read-State) }
        catch { $failure += ' Recovery also failed: ' + $_.Exception.Message }
    }
    [Console]::Error.WriteLine('Tag2 updater: ' + $failure)
    exit 1
} finally {
    if ($stage -and [IO.Directory]::Exists($stage)) { Remove-WorkDirectory $stage $stagingPath }
    if ($lock) { $lock.Dispose() }
}

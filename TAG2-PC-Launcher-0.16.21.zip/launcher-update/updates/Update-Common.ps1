Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.Net.Http
$script:Utf8 = New-Object Text.UTF8Encoding($false, $true)
$script:MaxArchiveBytes = [long]17179869184
$script:MaxExpandedBytes = [long]68719476736
$script:InterruptPayloadDownload = $false
$script:ReportPayloadProgress = $false

function Get-BytesHash([byte[]]$Bytes) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash($Bytes))).Replace('-', '').ToLowerInvariant() }
    finally { $sha.Dispose() }
}

function Assert-LocalPath([string]$Path) {
    $full = [IO.Path]::GetFullPath($Path)
    if ($full -notmatch '^[A-Za-z]:\\' -or $full.Substring(2).Contains(':')) { throw 'A local drive path without alternate data streams is required.' }
    $scan = $full
    while ($scan) {
        if (Test-Path -LiteralPath $scan) {
            if (((Get-Item -LiteralPath $scan -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw "Reparse points are forbidden: $scan"
            }
        }
        $parent = [IO.Directory]::GetParent($scan)
        if ($null -eq $parent) { break }
        $scan = $parent.FullName
    }
    return $full
}

function Remove-WorkDirectory([string]$Path, [string]$Parent) {
    $full = Assert-LocalPath $Path
    $allowed = (Assert-LocalPath $Parent).TrimEnd('\') + '\'
    if (-not $full.StartsWith($allowed, [StringComparison]::OrdinalIgnoreCase)) { throw 'Refusing removal outside the staging directory.' }
    if (Test-Path -LiteralPath $full) {
        foreach ($item in Get-ChildItem -LiteralPath $full -Recurse -Force) {
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Refusing staging cleanup containing a reparse point.' }
        }
        Remove-Item -LiteralPath $full -Recurse -Force
    }
}

function Write-DurableBytes([string]$Path, [byte[]]$Bytes) {
    $stream = New-Object IO.FileStream($Path, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None, 65536, [IO.FileOptions]::WriteThrough)
    try { $stream.Write($Bytes, 0, $Bytes.Length); $stream.Flush($true) }
    finally { $stream.Dispose() }
}

function Write-AtomicJson([string]$Path, $Value) {
    $null = Assert-LocalPath $Path
    $temp = $Path + '.' + [Guid]::NewGuid().ToString('N') + '.tmp'
    try {
        Write-DurableBytes $temp $script:Utf8.GetBytes(($Value | ConvertTo-Json -Depth 12 -Compress))
        if ([IO.File]::Exists($Path)) { [IO.File]::Replace($temp, $Path, [NullString]::Value) }
        else { [IO.File]::Move($temp, $Path) }
    } finally { if ([IO.File]::Exists($temp)) { [IO.File]::Delete($temp) } }
}

function Assert-ReleasePath([string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Name) -or $Name.Length -gt 220 -or $Name -match '[\\:<>"|?*\x00-\x1f]' -or $Name.StartsWith('/')) {
        throw "Unsafe archive path: $Name"
    }
    foreach ($part in $Name.TrimEnd('/').Split('/')) {
        if (-not $part -or $part -eq '.' -or $part -eq '..' -or $part -match '[. ]$' -or $part -match '^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)') {
            throw "Unsafe archive component: $Name"
        }
    }
}

function Assert-DownloadUri([uri]$Uri, [bool]$TestTransport) {
    if (-not $Uri.IsAbsoluteUri -or $Uri.UserInfo -or $Uri.Fragment) { throw 'Invalid release URI.' }
    if ($Uri.Scheme -eq 'https') { return }
    if ($TestTransport -and (($Uri.Scheme -eq 'file' -and -not $Uri.IsUnc) -or ($Uri.Scheme -eq 'http' -and $Uri.IsLoopback))) { return }
    throw 'Release downloads require HTTPS.'
}

function Copy-BoundedStream($Source, $Destination, [long]$Maximum) {
    $buffer = New-Object byte[] 65536
    $total = [long]0
    $lastReported = 0
    $deadline = [DateTime]::UtcNow.AddMinutes(30)
    while ($true) {
        $read = $Source.ReadAsync($buffer, 0, $buffer.Length)
        if (-not $read.Wait(60000)) { throw 'Download or archive read timed out.' }
        $count = $read.GetAwaiter().GetResult()
        if ($count -eq 0) { break }
        if ([DateTime]::UtcNow -gt $deadline) { throw 'Download or archive transfer exceeded thirty minutes.' }
        $total += $count
        if ($total -gt $Maximum) { throw 'Download or archive entry exceeds its permitted size.' }
        $Destination.Write($buffer, 0, $count)
        if ($script:ReportPayloadProgress -and $Maximum -gt 0) {
            $percent = [int](10 + 50 * $total / $Maximum)
            if ($percent -ge $lastReported + 5) {
                [Console]::Out.WriteLine('{"event":"progress","stage":"download","percent":' + $percent + '}')
                $lastReported = $percent
            }
        }
        if ($script:InterruptPayloadDownload -and $total -ge 32768) { [Environment]::Exit(73) }
    }
    return $total
}

function Get-VerifiedTransportFile([uri]$Uri, [string]$Destination, [long]$Maximum, [bool]$TestTransport) {
    Assert-DownloadUri $Uri $TestTransport
    $out = $null; $inputStream = $null; $client = $null; $response = $null; $handler = $null
    try {
        if ($Uri.Scheme -eq 'file') {
            $inputStream = [IO.File]::OpenRead((Assert-LocalPath $Uri.LocalPath))
        } else {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            $handler = New-Object Net.Http.HttpClientHandler
            $handler.AllowAutoRedirect = $false
            $client = New-Object Net.Http.HttpClient($handler)
            $client.Timeout = [TimeSpan]::FromMinutes(30)
            for ($redirect = 0; $redirect -le 5; $redirect++) {
                Assert-DownloadUri $Uri $TestTransport
                $response = $client.GetAsync($Uri, [Net.Http.HttpCompletionOption]::ResponseHeadersRead).GetAwaiter().GetResult()
                $status = [int]$response.StatusCode
                if ($status -in @(301, 302, 303, 307, 308)) {
                    if ($redirect -eq 5 -or $null -eq $response.Headers.Location) { throw 'Invalid or excessive download redirects.' }
                    $Uri = New-Object Uri($Uri, $response.Headers.Location)
                    $response.Dispose(); $response = $null
                    continue
                }
                $null = $response.EnsureSuccessStatusCode()
                if ($response.Content.Headers.ContentLength -gt $Maximum) { throw 'Download Content-Length exceeds the permitted size.' }
                $inputStream = $response.Content.ReadAsStreamAsync().GetAwaiter().GetResult()
                if ($inputStream.CanTimeout) { $inputStream.ReadTimeout = 60000 }
                break
            }
        }
        $out = New-Object IO.FileStream($Destination, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None, 65536, [IO.FileOptions]::WriteThrough)
        $total = Copy-BoundedStream $inputStream $out $Maximum
        $out.Flush($true)
        return $total
    } finally {
        if ($out) { $out.Dispose() }
        if ($inputStream) { $inputStream.Dispose() }
        if ($response) { $response.Dispose() }
        if ($client) { $client.Dispose() }
        if ($handler) { $handler.Dispose() }
    }
}

function Read-ManifestWithKey([byte[]]$Bytes, [byte[]]$Signature, [string]$PublicKeyXml, [long]$MinimumBuild, [long]$MaximumBuild) {
    if ($Bytes.Length -gt 65536 -or $Signature.Length -gt 1024) { throw 'Manifest or signature is too large.' }
    $rsa = [Security.Cryptography.RSA]::Create()
    try {
        $rsa.FromXmlString($PublicKeyXml)
        if ($rsa.KeySize -lt 3072) { throw 'The pinned RSA key must be at least 3072 bits.' }
        if (-not $rsa.VerifyData($Bytes, $Signature, [Security.Cryptography.HashAlgorithmName]::SHA256, [Security.Cryptography.RSASignaturePadding]::Pkcs1)) {
            throw 'Manifest signature verification failed.'
        }
    } finally { $rsa.Dispose() }
    $manifest = $script:Utf8.GetString($Bytes) | ConvertFrom-Json
    foreach ($field in @('schema', 'product', 'version', 'build', 'platform', 'channel', 'network_protocol', 'url', 'size', 'sha256', 'unpacked_size', 'entrypoint')) {
        if ($null -eq $manifest.PSObject.Properties[$field]) { throw "Manifest field is missing: $field" }
    }
    if ($manifest.schema -ne 1 -or $manifest.product -cne $script:Tag2Product -or $manifest.platform -cne $script:Tag2Platform -or $manifest.channel -cne $script:Tag2Channel) {
        throw 'Manifest product, platform, channel, or schema does not match this client.'
    }
    if ($manifest.version -isnot [string] -or $manifest.version -notmatch '^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$') { throw 'Version must be major.minor.patch.' }
    $null = [version]$manifest.version
    foreach ($field in @('build', 'network_protocol', 'size', 'unpacked_size')) {
        $number = $manifest.$field
        if (($number -isnot [int] -and $number -isnot [long]) -or $number -lt 1) { throw "Manifest field must be a positive integer: $field" }
    }
    if ($manifest.build -lt $MinimumBuild -or $manifest.build -gt $MaximumBuild -or $manifest.size -gt $script:MaxArchiveBytes -or $manifest.unpacked_size -gt $script:MaxExpandedBytes -or $manifest.sha256 -cnotmatch '^[a-f0-9]{64}$') {
        throw 'Manifest build, archive limits, or hash is invalid.'
    }
    if ($null -ne $manifest.PSObject.Properties['local_build_tools'] -and $manifest.local_build_tools -isnot [bool]) { throw 'local_build_tools must be a Boolean when present.' }
    Assert-ReleasePath $manifest.entrypoint
    if ($manifest.entrypoint.EndsWith('/')) { throw 'The entrypoint must be a file.' }
    Assert-DownloadUri ([uri]$manifest.url) $script:Tag2AllowTestTransport
    return $manifest
}


# Trust selection happens at the file/network boundary, never from unsigned metadata.
# Existing callers stay primary-only, including remote Check/Apply and signed Repair.
function Read-SignedManifest([byte[]]$Bytes, [byte[]]$Signature, [string]$PublicKeyXml) {
    if ($PublicKeyXml -cne $script:Tag2PublicKeyXml) { throw 'Remote releases require the primary pinned key.' }
    return Read-ManifestWithKey $Bytes $Signature $script:Tag2PublicKeyXml $script:Tag2MinimumBuild ([long]::MaxValue)
}

# Called only by Get-Release after resolving an installed versions/<id> directory.
# Legacy trust cannot authorize a remote release or a release newer than b36.
function Read-InstalledManifest([byte[]]$Bytes, [byte[]]$Signature) {
    try { return Read-SignedManifest $Bytes $Signature $script:Tag2PublicKeyXml }
    catch { }
    return Read-ManifestWithKey $Bytes $Signature $script:Tag2LegacyPublicKeyXml $script:Tag2LegacyMinimumBuild $script:Tag2LegacyMaximumBuild
}

function Assert-Payload([string]$Path, $Manifest) {
    if ((Get-Item -LiteralPath $Path).Length -ne $Manifest.size) { throw 'Payload size verification failed.' }
    if ((Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() -cne $Manifest.sha256) { throw 'Payload SHA-256 verification failed.' }
}

function Expand-SafePayload([string]$ArchivePath, [string]$Destination, $Manifest) {
    $stream = [IO.File]::OpenRead($ArchivePath)
    $zip = New-Object IO.Compression.ZipArchive($stream, [IO.Compression.ZipArchiveMode]::Read)
    try {
        if ($zip.Entries.Count -gt 100000) { throw 'Archive has too many entries.' }
        $seen = New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
        $total = [long]0
        foreach ($entry in $zip.Entries) {
            Assert-ReleasePath $entry.FullName
            if (-not $seen.Add($entry.FullName.TrimEnd('/'))) { throw 'Duplicate or case-colliding archive entry.' }
            $unixType = ($entry.ExternalAttributes -shr 16) -band 61440
            if ($unixType -eq 40960 -or ($entry.ExternalAttributes -band 1024) -ne 0) { throw 'Archive links are forbidden.' }
            $total += $entry.Length
            if ($total -gt $Manifest.unpacked_size) { throw 'Archive expands beyond its signed size.' }
            $path = Join-Path $Destination $entry.FullName.Replace('/', '\')
            if ($entry.FullName.EndsWith('/')) {
                if ($entry.Length -ne 0) { throw 'Archive directory contains data.' }
                $null = [IO.Directory]::CreateDirectory($path)
                continue
            }
            $null = [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($path))
            $source = $entry.Open(); $target = $null
            try {
                $target = New-Object IO.FileStream($path, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None, 65536, [IO.FileOptions]::WriteThrough)
                if ((Copy-BoundedStream $source $target $entry.Length) -ne $entry.Length) { throw 'Archive entry is truncated.' }
                $target.Flush($true)
            } finally { if ($target) { $target.Dispose() }; $source.Dispose() }
        }
        if ($total -ne $Manifest.unpacked_size) { throw 'Archive expanded size does not match its manifest.' }
        $entrypoint = Join-Path $Destination $Manifest.entrypoint.Replace('/', '\')
        if (-not [IO.File]::Exists($entrypoint) -or (Get-Item -LiteralPath $entrypoint).Length -eq 0) { throw 'Release entrypoint is missing or empty.' }
    } finally { $zip.Dispose(); $stream.Dispose() }
}

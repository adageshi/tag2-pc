# Signed launcher repair for clients whose original updater only activates versioned games.
[Threading.Thread]::CurrentThread.CurrentUICulture = [Globalization.CultureInfo]::GetCultureInfo('en-US')
[Threading.Thread]::CurrentThread.CurrentCulture = [Globalization.CultureInfo]::InvariantCulture
$ErrorActionPreference='Stop'
$app=[IO.DirectoryInfo]$PSScriptRoot;$version=$app.Parent
if($app.Name -cne 'app' -or $version.Name -cnotmatch '^b[1-9][0-9]*-[a-f0-9]{64}$' -or $version.Parent.Name -cne 'versions'){throw 'Run this repair from an installed signed update.'}
$root=$version.Parent.Parent.FullName
. (Join-Path $root 'updates\Update-Common.ps1')
. (Join-Path $root 'updates\Trust-Tag2.ps1')
$root=Assert-LocalPath $root;$archive=Assert-LocalPath (Join-Path $version.FullName 'payload.zip')
$manifest=Read-SignedManifest ([IO.File]::ReadAllBytes((Join-Path $version.FullName 'manifest.json'))) ([IO.File]::ReadAllBytes((Join-Path $version.FullName 'manifest.sig'))) $script:Tag2PublicKeyXml
if($version.Name -cne ('b'+$manifest.build+'-'+$manifest.sha256) -or $manifest.entrypoint -cne 'bin/Tag2Update.exe'){throw 'The signed launcher update identity is invalid.'}
$state=Get-Content -LiteralPath (Assert-LocalPath (Join-Path $root 'state.json')) -Raw|ConvertFrom-Json
if($state.current -cne $version.Name){throw 'This launcher update is not active.'}
Assert-Payload $archive $manifest
$stream=[IO.File]::OpenRead($archive);$zip=New-Object IO.Compression.ZipArchive($stream,[IO.Compression.ZipArchiveMode]::Read)
$staged=[Collections.Generic.List[object]]::new();$backup=Join-Path $root ('updates\launcher-backup-'+$manifest.build+'-'+[Guid]::NewGuid().ToString('N').Substring(0,8))
try {
 foreach($name in @('updates/Update-Common.ps1','updates/Trust-Tag2.ps1','updates/Update-Tag2.ps1','bin/Tag2Controllers.exe','Tag2.Launcher.Core.dll','Tag2Launcher.exe','Tag2Launcher.exe.config')){
  $entry=$zip.GetEntry($name)
  if($null -eq $entry -or $entry.Length -lt 1 -or $entry.Length -gt 4MB){throw 'A signed launcher component is missing or too large.'}
  $input=$entry.Open();$buffer=New-Object IO.MemoryStream
  try{if((Copy-BoundedStream $input $buffer $entry.Length) -ne $entry.Length){throw 'Truncated launcher component'};$bytes=$buffer.ToArray()}finally{$input.Dispose();$buffer.Dispose()}
  $target=Assert-LocalPath (Join-Path $root $name.Replace('/','\'));$hash=Get-BytesHash $bytes
  [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target))
  if([IO.File]::Exists($target) -and (Get-FileHash -LiteralPath $target).Hash.ToLowerInvariant() -ceq $hash){Unblock-File -LiteralPath $target;continue}
  $temp=Assert-LocalPath ($target+'.'+[Guid]::NewGuid().ToString('N')+'.tmp')
  Write-DurableBytes $temp $bytes
  $staged.Add([pscustomobject]@{name=$name;target=$target;temp=$temp;hash=$hash})
 }
 if($staged.Count){[void][IO.Directory]::CreateDirectory($backup)}
 foreach($file in $staged){
  [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName((Join-Path $backup $file.name)))
  if([IO.File]::Exists($file.target)){[IO.File]::Replace($file.temp,$file.target,(Join-Path $backup $file.name))}else{[IO.File]::Move($file.temp,$file.target)}
  if((Get-FileHash -LiteralPath $file.target).Hash.ToLowerInvariant() -cne $file.hash){throw 'Launcher repair integrity check failed.'}
  # ReplaceFile preserves the previous download mark; clear it only after signed-byte verification.
  Unblock-File -LiteralPath $file.target
 }
 'LAUNCHER_REPAIR_COMPLETE'
}finally{
 foreach($file in $staged){if([IO.File]::Exists($file.temp)){[IO.File]::Delete($file.temp)}}
 $zip.Dispose();$stream.Dispose()
}

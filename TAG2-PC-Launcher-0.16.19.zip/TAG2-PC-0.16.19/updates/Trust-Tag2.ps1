# Bootstrap trust is distributed with the client, never downloaded from the feed.
# TAG2 preview release key provisioned by release engineering on 2026-10-18.
$script:Tag2PublicKeyXml = '<RSAKeyValue><Modulus>0ZEyNGCVpgutkjXkfY7l7i2oUwHyiEv3NDqHCwo+IyqVgXB8s7Xt1QTVQCMz73MteXokPc3W+s25CodPYwNj2423PF3tUQAD3ZUaeGpyg5vN7ZaEAAO84ak5rc81gngduR4cmxQ5DVvbhOqfhVizz9O8LbyPAykvdibhJjn+qW8MT0V/8thIrUhxrq1X+77iIkFVUaBlLu7Ch1vmGIIgObSdyBTQIUJZCWeZccPi/Cmw45dXJe4H30Gb1t0FU1DOAWebuiCTstOmVwCFb+7PNvLTVCYjosQD0+kUbK3Jj3pX7zr36VJDaBnaDS8t5JkYXIRcpddmNudRwO1pFqIvYkZwKNGeVl2v/a4PWtu8pQBdlhbaEEP0pQNGOwkp5UD4aqEHHrvS4WoPYlwCSPBlPE7lU7d1zPgdJgttIiKfcepxYkKY6kckac7QhtCXB0H6VGtVqG2CsaelJeXGKJAbX1xySObkMapCj4MZNoWvpLaWrGScq6HZJJnbCS9DMyIp</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>'
$script:Tag2Product = 'tag2-pc'
$script:Tag2Platform = 'windows-x64'
$script:Tag2Channel = 'preview'
$script:Tag2MinimumBuild = [long]16
$script:Tag2AllowTestTransport = $false
$script:Tag2AllowTestInterruptions = $false

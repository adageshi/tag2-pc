TAG2 PC 0.16.18

Extract this complete folder on a local fixed NTFS drive.
Run Tag2Launcher.exe, then choose Install update to fetch required components.
The launcher restarts. Use your own original game ISO and supported Title Update.
Existing users should update their existing launcher folder to retain their account.

TAG2 PC - Standalone benchmark capture

No game version or release hash is required. This tool does not update,
rebuild or change the game. The same ZIP can be reused after game updates.
Windows x64 and .NET Framework 4.8 are required, as for the launcher.

1. Extract this entire ZIP to a writable local folder. Keep all files together.
   It does not need to be in the game folder.
2. Start exactly one TAG2 game and enter offline Practice.
3. Run TAG2-Benchmark.exe. Approve the Windows administrator prompt for
   PresentMon's timing capture.
4. Select Offline Practice. In the optional note, enter the resolution,
   stage and characters, for example: 2x, Kazuya vs Jin, Philippines.
5. Click START CAPTURE, return to the game during the 10-second countdown,
   and play for the full 30 seconds. Stay in combat and keep the game focused.
6. Send the newly generated TAG2-Capture-<date>-<id>.zip beside this tool.
   Repeat the same scene at 1x, 2x and 3x when comparing rendering performance.

Online match mode records up to 10 minutes. Start before the match loads.
Ctrl+Alt+F7: mark combat/menu transitions.
Ctrl+Alt+F9: stop and save early.
Ctrl+Alt+F8: optional game screenshot. Avoid screenshots during timing
comparisons: taking one can affect frames. Inspect screenshots before sharing;
they may include visible player names or overlays.

The result includes frame timings, foreground status, hardware/driver details,
approved graphics settings, actual executable/module SHA-256 hashes and
filtered numeric game diagnostics. A build receipt is optional. A missing,
unreadable or mismatched receipt never rejects a game version. Its recorded
values are observations, not proof that the game is an official release.

No account files, credentials, saves, raw command lines, key recordings,
system-wide ETL files or unrelated application frame rows are exported.
Nothing is uploaded automatically. Do not put private information in the
optional note, which is included in the result.

Presentation rate is not simulation FPS. CPU frame start to estimated display
is not physical press-to-screen latency. Combat markers are manual annotations;
foreground samples can still contain menus. Empty/failed captures are labelled
as failures in metadata.json and must not be treated as good performance.

This tool detects the TAG2 executable named TekkenTag2Hints.exe. Run one
client at a time on each PC. In an online test, each player captures locally.

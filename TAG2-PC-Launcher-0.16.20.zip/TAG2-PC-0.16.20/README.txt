TAG2 PC 0.16.20

Extract the complete folder to a local fixed NTFS drive.
Run Tag2Launcher.exe, then choose Install update for the required components.
Use your own original game and supported Xbox 360 Title Update.
Existing players should update their current folder to retain account and saves.
